jQuery(document).ready(function($) {
    const fieldsContainer = $('#cfe-form-fields-container');
    const fieldTemplate = `
        <div class="cfe-field-item">
            <div class="cfe-field-handle">
                <span class="dashicons dashicons-move"></span>
            </div>
            <div class="cfe-field-content">
                <div class="cfe-form-group">
                    <label>Tên trường</label>
                    <input type="text" name="cfe_form_fields[__index__][label]" value="" placeholder="Tên của bạn" required>
                </div>
                <div class="cfe-form-group">
                    <label>Slug (tên biến)</label>
                    <input type="text" name="cfe_form_fields[__index__][name]" value="" placeholder="your-name" required>
                </div>
                <div class="cfe-form-group">
                    <label>Loại trường</label>
                    <select name="cfe_form_fields[__index__][type]">
                        <option value="text">Văn bản</option>
                        <option value="email">Email</option>
                        <option value="textarea">Tin nhắn</option>
                    </select>
                </div>
                <div class="cfe-form-group-inline">
                    <input type="checkbox" name="cfe_form_fields[__index__][required]" value="1">
                    <label>Bắt buộc?</label>
                </div>
            </div>
            <button type="button" class="cfe-remove-field-btn"><span class="dashicons dashicons-trash"></span></button>
        </div>
    `;

    function updateFieldIndexes() {
        fieldsContainer.find('.cfe-field-item').each(function(index) {
            $(this).find('input, select').each(function() {
                this.name = this.name.replace(/cfe_form_fields\[\d+\]/, `cfe_form_fields[${index}]`);
            });
        });
    }

    $('#cfe-add-field-btn').on('click', function() {
        const newField = $(fieldTemplate.replace(/__index__/g, fieldsContainer.children().length));
        fieldsContainer.append(newField);
    });

    fieldsContainer.on('click', '.cfe-remove-field-btn', function() {
        $(this).closest('.cfe-field-item').remove();
        updateFieldIndexes();
    });

    fieldsContainer.sortable({
        items: '.cfe-field-item',
        handle: '.cfe-field-handle',
        axis: 'y',
        cursor: 'grabbing',
        stop: function() {
            updateFieldIndexes();
        }
    });
});