jQuery(document).ready(function($) {
    $('.cfe-contact-form').on('submit', function(e) {
        e.preventDefault();

        const form = $(this);
        const formId = form.data('form-id');
        const submitButton = form.find('.cfe-submit-button');
        const messageDiv = $('#cfe-form-message-' + formId);

        messageDiv.removeClass('success error').text('Đang gửi...').slideDown();
        submitButton.prop('disabled', true);

        const formData = new FormData(this);
        formData.append('action', 'cfe_submit_contact_form');
        formData.append('nonce', cfe_ajax_object.nonce);
        formData.append('form_id', formId);

        $.ajax({
            type: 'POST',
            url: cfe_ajax_object.ajax_url,
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    messageDiv.addClass('success').text(response.data);
                    form[0].reset();
                } else {
                    messageDiv.addClass('error').text(response.data);
                }
            },
            error: function() {
                messageDiv.addClass('error').text('Đã xảy ra lỗi không xác định.');
            },
            complete: function() {
                submitButton.prop('disabled', false);
            }
        });
    });
});