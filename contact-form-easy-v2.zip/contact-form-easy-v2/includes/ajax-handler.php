<?php
/**
 * Xử lý form liên hệ qua AJAX và tải tài nguyên cho form.
 */

defined( 'ABSPATH' ) or die( 'Không có quyền truy cập trực tiếp.' );

/**
 * Enqueue scripts và styles cho form liên hệ.
 */
function cfe_enqueue_contact_form_assets() {
    global $post;

    // Chỉ enqueue nếu shortcode tồn tại trong nội dung bài viết/trang
    if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'cfe_contact_form' ) ) {
        wp_enqueue_style( 'cfe-contact-form-style', CFE_PLUGIN_URL . 'assets/css/frontend-form.css', array(), '1.0' );
        wp_enqueue_script( 'cfe-contact-form-script', CFE_PLUGIN_URL . 'assets/js/frontend-form.js', array('jquery'), '1.0', true );
        wp_localize_script( 'cfe-contact-form-script', 'cfe_ajax_object', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cfe_contact_form_nonce'),
        ) );
    }
}
add_action( 'wp_enqueue_scripts', 'cfe_enqueue_contact_form_assets' );

/**
 * Xử lý form liên hệ qua AJAX.
 */
function cfe_handle_contact_form() {
    check_ajax_referer( 'cfe_contact_form_nonce', 'nonce' );

    global $wpdb;
    $table_name = $wpdb->prefix . 'cfe_contacts';

    $form_id = isset($_POST['form_id']) ? intval($_POST['form_id']) : 0;
    $form_post = get_post( $form_id );

    if ( !$form_post || $form_post->post_type !== 'cfe_contact_form' ) {
        wp_send_json_error('Lỗi: Form không tồn tại.');
    }

    $fields_meta = get_post_meta( $form_id, 'cfe_form_fields', true );
    $fields_meta = is_array($fields_meta) ? $fields_meta : array();
    $email_settings = get_post_meta( $form_id, 'cfe_email_settings', true );
    $autoresponder_settings = get_post_meta( $form_id, 'cfe_autoresponder_settings', true );
    $recaptcha_enabled = get_post_meta( $form_id, 'cfe_recaptcha_enabled', true );

    // Xử lý reCAPTCHA nếu được bật
    if ( $recaptcha_enabled ) {
        $recaptcha_secret = get_option('cfe_recaptcha_secret_key');
        $recaptcha_response = isset($_POST['g-recaptcha-response']) ? sanitize_text_field($_POST['g-recaptcha-response']) : '';

        if (empty($recaptcha_response)) {
            wp_send_json_error('Vui lòng xác thực reCAPTCHA.');
        }

        $response = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array(
            'body' => array(
                'secret'   => $recaptcha_secret,
                'response' => $recaptcha_response,
                'remoteip' => $_SERVER['REMOTE_ADDR']
            )
        ) );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error('Lỗi xác thực reCAPTCHA: ' . $response->get_error_message());
        }

        $body = wp_remote_retrieve_body( $response );
        $result = json_decode( $body );

        if ( ! $result->success ) {
            wp_send_json_error('Xác thực reCAPTCHA không thành công.');
        }
    }

    $form_data = array();
    $sender_name = '';
    $sender_email = '';

    // Lấy và kiểm tra dữ liệu form
    foreach ($fields_meta as $field) {
        $field_name = sanitize_title($field['name']);
        $value = isset($_POST[$field_name]) ? wp_unslash($_POST[$field_name]) : '';

        // Kiểm tra trường bắt buộc
        if ( isset($field['required']) && $field['required'] == '1' && empty($value) ) {
            wp_send_json_error('Vui lòng điền đầy đủ thông tin.');
        }

        // Lấy tên và email người gửi
        if (isset($field['type']) && $field['type'] === 'email') {
            $sender_email = sanitize_email($value);
        } elseif (isset($field['name']) && $field['name'] === 'sender_name') {
            $sender_name = sanitize_text_field($value);
        }

        $form_data[$field_name] = sanitize_text_field($value);
    }
    
    // Ghi dữ liệu vào database
    $wpdb->insert(
        $table_name,
        array(
            'form_id' => $form_id,
            'sender_name' => $sender_name,
            'sender_email' => $sender_email,
            'raw_data' => json_encode($form_data),
            'submission_date' => current_time('mysql'),
            'read_status' => 0
        ),
        array('%d', '%s', '%s', '%s', '%s', '%d')
    );

    $contact_id = $wpdb->insert_id;

    // Gửi email thông báo
    $recipient = isset($email_settings['recipient']) ? $email_settings['recipient'] : get_bloginfo('admin_email');
    $subject = isset($email_settings['subject']) ? $email_settings['subject'] : 'Thông tin liên hệ mới';
    $template = isset($email_settings['template']) ? $email_settings['template'] : 'Dữ liệu liên hệ sẽ được gửi tại đây';

    $template = str_replace('{sender_name}', $sender_name, $template);
    $template = str_replace('{sender_email}', $sender_email, $template);

    foreach ($form_data as $key => $value) {
        $template = str_replace('{' . $key . '}', $value, $template);
    }

    $headers = array('Content-Type: text/html; charset=UTF-8');
    wp_mail($recipient, $subject, nl2br($template), $headers);

    // Gửi email phản hồi tự động nếu được bật
    if (isset($autoresponder_settings['enabled']) && $autoresponder_settings['enabled'] == '1' && !empty($sender_email)) {
        $auto_subject = isset($autoresponder_settings['subject']) ? $autoresponder_settings['subject'] : 'Cảm ơn bạn đã liên hệ!';
        $auto_body = isset($autoresponder_settings['body']) ? $autoresponder_settings['body'] : 'Cảm ơn bạn đã gửi liên hệ. Chúng tôi sẽ phản hồi lại bạn sớm nhất có thể!';
        
        $auto_body = str_replace('{sender_name}', $sender_name, $auto_body);
        $auto_body = str_replace('{sender_email}', $sender_email, $auto_body);
        
        wp_mail($sender_email, $auto_subject, nl2br($auto_body), $headers);
    }

    wp_send_json_success('Form đã được gửi thành công!');
}
add_action('wp_ajax_cfe_submit_contact_form', 'cfe_handle_contact_form');
add_action('wp_ajax_nopriv_cfe_submit_contact_form', 'cfe_handle_contact_form');