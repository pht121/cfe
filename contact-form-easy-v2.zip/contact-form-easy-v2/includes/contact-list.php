<?php
/**
 * Chức năng hiển thị danh sách liên hệ đã gửi và xem chi tiết.
 */

defined( 'ABSPATH' ) or die( 'Không có quyền truy cập trực tiếp.' );

if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

/**
 * Class hiển thị bảng danh sách liên hệ.
 */
class CFE_Contacts_List_Table extends WP_List_Table {
    private $table_name;

    function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'cfe_contacts';

        parent::__construct( array(
            'singular' => 'contact',
            'plural'   => 'contacts',
            'ajax'     => false
        ) );
    }

    function get_columns() {
        $columns = array(
            'cb'            => '<input type="checkbox" />',
            'sender_name'   => 'Tên người gửi',
            'sender_email'  => 'Email người gửi',
            'form_name'     => 'Form',
            'submission_date' => 'Ngày gửi',
        );
        return $columns;
    }

    function column_default( $item, $column_name ) {
        switch( $column_name ) {
            case 'sender_name':
                $view_link = add_query_arg(
                    array(
                        'page' => 'cfe-contacts',
                        'action' => 'view',
                        'contact_id' => absint($item['id']),
                    ),
                    admin_url('admin.php')
                );
                $delete_link = wp_nonce_url(
                    add_query_arg(
                        array(
                            'page' => 'cfe-contacts',
                            'action' => 'delete',
                            'contact' => absint($item['id']),
                        ),
                        admin_url('admin.php')
                    ),
                    'cfe_delete_contact_' . absint($item['id'])
                );
                
                $actions = array(
                    'view' => sprintf('<a href="%s">Xem chi tiết</a>', esc_url($view_link)),
                    'delete' => sprintf('<a href="%s" onclick="return confirm(\'Bạn có chắc chắn muốn xóa liên hệ này không?\');">Xóa</a>', esc_url($delete_link))
                );

                return sprintf('<strong><a href="%1$s">%2$s</a></strong>%3$s', esc_url($view_link), esc_html($item['sender_name']), $this->row_actions($actions));
            case 'sender_email':
                return esc_html($item['sender_email']);
            case 'form_name':
                $form_title = get_the_title($item['form_id']);
                return $form_title ? esc_html($form_title) : 'Không rõ';
            case 'submission_date':
                return date('d/m/Y H:i', strtotime($item['submission_date']));
            default:
                return print_r($item, true);
        }
    }

    function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            $this->_args['singular'],
            $item['id']
        );
    }
    
    function get_sortable_columns() {
        $sortable_columns = array(
            'submission_date' => array('submission_date', false),
            'sender_name' => array('sender_name', false),
            'sender_email' => array('sender_email', false),
        );
        return $sortable_columns;
    }

    function get_bulk_actions() {
        $actions = array(
            'delete' => 'Xóa'
        );
        return $actions;
    }

    function process_bulk_action() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'cfe_contacts';
        
        if ('delete' === $this->current_action()) {
            check_admin_referer('bulk-' . $this->_args['plural']);
            $contact_ids = isset($_POST['contact']) ? (array)$_POST['contact'] : array();
            
            if (!empty($contact_ids)) {
                $ids_in = implode(',', array_map('absint', $contact_ids));
                $wpdb->query("DELETE FROM {$table_name} WHERE id IN($ids_in)");
            }
        }
    }

    function prepare_items() {
        global $wpdb;
        $per_page = 20;
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array($columns, $hidden, $sortable);
        
        $this->process_bulk_action();

        $current_page = $this->get_pagenum();
        $offset = ($current_page - 1) * $per_page;
        
        $orderby = isset($_GET['orderby']) ? sanitize_sql_orderby($_GET['orderby']) : 'submission_date';
        $order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : 'DESC';

        $where_clauses = array();
        
        // Thêm bộ lọc form
        if (isset($_GET['form_id']) && $_GET['form_id'] !== 'all') {
            $form_id = absint($_GET['form_id']);
            $where_clauses[] = $wpdb->prepare("form_id = %d", $form_id);
        }

        // Thêm bộ lọc thời gian
        if (isset($_GET['filter_by_date']) && $_GET['filter_by_date'] !== 'all') {
            $current_time = current_time('mysql');
            switch ($_GET['filter_by_date']) {
                case 'today':
                    $start_date = date('Y-m-d 00:00:00', strtotime($current_time));
                    break;
                case '7days':
                    $start_date = date('Y-m-d 00:00:00', strtotime($current_time . ' -7 days'));
                    break;
                case '30days':
                    $start_date = date('Y-m-d 00:00:00', strtotime($current_time . ' -30 days'));
                    break;
                case '1year':
                    $start_date = date('Y-m-d 00:00:00', strtotime($current_time . ' -1 year'));
                    break;
                default:
                    $start_date = '';
            }

            if (!empty($start_date)) {
                $where_clauses[] = $wpdb->prepare("submission_date >= %s", $start_date);
            }
        }

        // Thêm tìm kiếm
        if (isset($_GET['s']) && !empty($_GET['s'])) {
            $search_term = '%' . $wpdb->esc_like(sanitize_text_field($_GET['s'])) . '%';
            $where_clauses[] = $wpdb->prepare("(sender_name LIKE %s OR sender_email LIKE %s)", $search_term, $search_term);
        }

        $where_sql = count($where_clauses) > 0 ? ' WHERE ' . implode(' AND ', $where_clauses) : '';
        
        $query = "SELECT * FROM {$this->table_name} {$where_sql} ORDER BY {$orderby} {$order} LIMIT {$per_page} OFFSET {$offset}";
        
        $this->items = $wpdb->get_results($query, ARRAY_A);
        
        $total_items_query = "SELECT COUNT(id) FROM {$this->table_name} {$where_sql}";
        $total_items = $wpdb->get_var($total_items_query);
        
        $this->set_pagination_args( array(
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ) );
    }

    function get_search_box() {
        $search_term = isset($_GET['s']) ? esc_attr($_GET['s']) : '';
        $text = 'Tìm kiếm'; 
        
        if ( ! $this->has_items() && ! $search_term ) {
            return;
        }

        $input_id = 'media-search-input';
        
        if ( ! empty( $_REQUEST['mode'] ) ) {
            $input_id = 'search-by-email-input';
        }

        $this->search_box($text, $input_id);
    }

    function extra_tablenav( $which ) {
        if ( 'top' !== $which ) {
            return;
        }
    
        $selected_form = isset($_GET['form_id']) ? sanitize_text_field($_GET['form_id']) : 'all';
        $selected_date = isset($_GET['filter_by_date']) ? sanitize_text_field($_GET['filter_by_date']) : 'all';
    
        $args = array(
            'post_type' => 'cfe_contact_form',
            'posts_per_page' => -1,
            'post_status' => 'publish',
        );
        $forms = get_posts($args);
    
        echo '<div class="alignleft actions">';
        if ($forms) {
            echo '<label for="filter-by-form" class="screen-reader-text">Lọc theo form</label>';
            echo '<select name="form_id" id="filter-by-form">';
            echo '<option value="all">Tất cả Forms</option>';
    
            foreach ($forms as $form) {
                $selected = selected($selected_form, $form->ID, false);
                echo '<option value="' . esc_attr($form->ID) . '" ' . $selected . '>' . esc_html($form->post_title) . '</option>';
            }
            echo '</select>';
        }

        echo '<label for="filter-by-date" class="screen-reader-text">Lọc theo ngày</label>';
        echo '<select name="filter_by_date" id="filter-by-date">';
        echo '<option value="all">Tất cả thời gian</option>';
        echo '<option value="today" ' . selected($selected_date, 'today', false) . '>Hôm nay</option>';
        echo '<option value="7days" ' . selected($selected_date, '7days', false) . '>7 ngày qua</option>';
        echo '<option value="30days" ' . selected($selected_date, '30days', false) . '>30 ngày qua</option>';
        echo '<option value="1year" ' . selected($selected_date, '1year', false) . '>1 năm qua</option>';
        echo '</select>';

        submit_button('Lọc', 'button', false, false, array('id' => 'post-query-submit'));
        echo '</div>';
    }
}

/**
 * Thêm menu con "Danh sách liên hệ"
 */
function cfe_add_contacts_list_menu() {
    add_submenu_page(
        'cfe-main-menu',
        'Danh sách liên hệ',
        'Danh sách liên hệ',
        'manage_options',
        'cfe-contacts',
        'cfe_render_contacts_page'
    );
}
add_action( 'admin_menu', 'cfe_add_contacts_list_menu' );

/**
 * Hiển thị trang quản lý liên hệ (danh sách hoặc chi tiết).
 */
function cfe_render_contacts_page() {
    if ( isset($_GET['action']) && $_GET['action'] == 'view' && isset($_GET['contact_id']) ) {
        cfe_render_contact_details_page();
    } else {
        $contacts_table = new CFE_Contacts_List_Table();
        $contacts_table->prepare_items();
        ?>
        <div class="wrap">
            <h1>Danh sách liên hệ</h1>
            <div style="margin-bottom: 15px;">
                <a href="<?php echo esc_url(add_query_arg('action', 'export_csv', admin_url('admin.php?page=cfe-contacts'))); ?>" class="button button-primary">Xuất CSV</a>
                <a href="<?php echo esc_url(add_query_arg('action', 'export_html', admin_url('admin.php?page=cfe-contacts'))); ?>" class="button">Xuất HTML</a>
            </div>
            <form method="post">
                <?php $contacts_table->display(); ?>
            </form>
        </div>
        <?php
    }
}

/**
 * Hiển thị trang chi tiết liên hệ.
 */
function cfe_render_contact_details_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'cfe_contacts';
    $contact_id = absint($_GET['contact_id']);

    if ( ! $contact_id ) {
        echo '<p>Lỗi: ID liên hệ không hợp lệ.</p>';
        return;
    }

    $contact = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $contact_id), ARRAY_A);

    if ( ! $contact ) {
        echo '<p>Lỗi: Không tìm thấy liên hệ.</p>';
        return;
    }

    $form_title = get_the_title($contact['form_id']);
    $raw_data = json_decode($contact['raw_data'], true);
    $back_link = admin_url('admin.php?page=cfe-contacts');

    // Lấy thông tin các trường của form từ post meta
    $fields_meta = get_post_meta($contact['form_id'], 'cfe_form_fields', true);
    $field_labels = array();
    if (is_array($fields_meta)) {
        foreach ($fields_meta as $field) {
            $field_labels[$field['name']] = $field['label'];
        }
    }
    ?>
    <div class="wrap">
        <h1>Chi tiết liên hệ</h1>
        <a href="<?php echo esc_url($back_link); ?>" class="button-primary">&laquo; Quay lại danh sách</a>
        <br><br>
        <table class="form-table">
            <tbody>
                <tr>
                    <th>Form</th>
                    <td><?php echo esc_html($form_title); ?></td>
                </tr>
                <tr>
                    <th>Ngày gửi</th>
                    <td><?php echo date('d/m/Y H:i', strtotime($contact['submission_date'])); ?></td>
                </tr>
                <?php foreach ($raw_data as $key => $value): ?>
                <tr>
                    <th><?php echo isset($field_labels[$key]) ? esc_html($field_labels[$key]) : esc_html(ucfirst(str_replace('-', ' ', $key))); ?></th>
                    <td><?php echo nl2br(esc_html($value)); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

/**
 * Hàm xử lý việc xuất danh sách liên hệ (CSV hoặc HTML).
 */
function cfe_handle_export() {
    if ( ! current_user_can('manage_options') || ! isset($_GET['page']) || $_GET['page'] !== 'cfe-contacts' || ! isset($_GET['action']) || ! in_array($_GET['action'], array('export_csv', 'export_html')) ) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'cfe_contacts';
    $contacts = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY submission_date DESC", ARRAY_A);

    if (empty($contacts)) {
        wp_die('Không có dữ liệu để xuất.');
    }

    $all_keys = array();
    foreach ($contacts as $contact) {
        $raw_data = json_decode($contact['raw_data'], true);
        if (is_array($raw_data)) {
            $all_keys = array_merge($all_keys, array_keys($raw_data));
        }
    }
    $all_keys = array_unique($all_keys);
    
    $header = array('ID Liên hệ', 'Form', 'Ngày gửi', 'Tên người gửi', 'Email người gửi');
    $header = array_merge($header, $all_keys);

    if ($_GET['action'] === 'export_csv') {
        cfe_export_to_csv($contacts, $header, $all_keys);
    } elseif ($_GET['action'] === 'export_html') {
        cfe_export_to_html($contacts, $header, $all_keys);
    }

}
add_action('admin_init', 'cfe_handle_export');


/**
 * Xuất dữ liệu ra file CSV.
 */
function cfe_export_to_csv($contacts, $header, $all_keys) {
    $filename = 'contact-list-' . date('Y-m-d') . '.csv';

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    fputs($output, $bom = chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($output, $header);

    foreach ($contacts as $contact) {
        $raw_data = json_decode($contact['raw_data'], true);
        $line = array(
            $contact['id'],
            get_the_title($contact['form_id']),
            $contact['submission_date'],
            $contact['sender_name'],
            $contact['sender_email'],
        );
        foreach ($all_keys as $key) {
            $value = isset($raw_data[$key]) ? $raw_data[$key] : '';
            $line[] = $value;
        }
        fputcsv($output, $line);
    }
    fclose($output);
    exit;
}

/**
 * Xuất dữ liệu ra file HTML.
 */
function cfe_export_to_html($contacts, $header, $all_keys) {
    $filename = 'contact-list-' . date('Y-m-d') . '.html';

    header('Content-Type: text/html; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = '<html><head><meta charset="UTF-8"><title>Danh sách liên hệ</title><style>table, th, td { border: 1px solid black; border-collapse: collapse; padding: 8px; } table { width: 100%; }</style></head><body>';
    $output .= '<h1>Danh sách liên hệ</h1>';
    $output .= '<table><thead><tr>';
    foreach ($header as $col) {
        $output .= '<th>' . esc_html($col) . '</th>';
    }
    $output .= '</tr></thead><tbody>';

    foreach ($contacts as $contact) {
        $raw_data = json_decode($contact['raw_data'], true);
        $output .= '<tr>';
        $output .= '<td>' . esc_html($contact['id']) . '</td>';
        $output .= '<td>' . esc_html(get_the_title($contact['form_id'])) . '</td>';
        $output .= '<td>' . esc_html($contact['submission_date']) . '</td>';
        $output .= '<td>' . esc_html($contact['sender_name']) . '</td>';
        $output .= '<td>' . esc_html($contact['sender_email']) . '</td>';

        foreach ($all_keys as $key) {
            $value = isset($raw_data[$key]) ? $raw_data[$key] : '';
            $output .= '<td>' . esc_html($value) . '</td>';
        }
        $output .= '</tr>';
    }

    $output .= '</tbody></table></body></html>';
    echo $output;
    exit;
}