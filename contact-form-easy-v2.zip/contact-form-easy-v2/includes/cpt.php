<?php
/**
 * Đăng ký Custom Post Type cho Form Liên hệ.
 */

defined( 'ABSPATH' ) or die( 'Không có quyền truy cập trực tiếp.' );

/**
 * Đăng ký Custom Post Type cho Form Liên hệ.
 */
function cfe_register_contact_form_post_type() {
    $labels = array(
        'name'                  => _x( 'Form Liên hệ', 'Post Type General Name', 'contact-form-easy' ),
        'singular_name'         => _x( 'Form Liên hệ', 'Post Type Singular Name', 'contact-form-easy' ),
        'menu_name'             => __( 'Form Liên hệ', 'contact-form-easy' ),
        'all_items'             => __( 'Tất cả Forms', 'contact-form-easy' ),
        'add_new_item'          => __( 'Thêm Form mới', 'contact-form-easy' ),
        'add_new'               => __( 'Thêm mới', 'contact-form-easy' ),
        'edit_item'             => __( 'Chỉnh sửa Form', 'contact-form-easy' ),
        'update_item'           => __( 'Cập nhật Form', 'contact-form-easy' ),
        'view_item'             => __( 'Xem Form', 'contact-form-easy' ),
    );
    $args = array(
        'label'                 => __( 'Form Liên hệ', 'contact-form-easy' ),
        'labels'                => $labels,
        'supports'              => array( 'title' ),
        'public'                => false,
        'show_ui'               => true,
        'show_in_menu'          => 'cfe-main-menu', // Đã sửa: Liên kết với menu cha mới
        'capability_type'       => 'post',
        'rewrite'               => false,
    );
    register_post_type( 'cfe_contact_form', $args );
}
add_action( 'init', 'cfe_register_contact_form_post_type', 0 );