<?php
/**
 * Tạo Meta Box cho form.
 */

defined( 'ABSPATH' ) or die( 'Không có quyền truy cập trực tiếp.' );

/**
 * Thêm Meta Box tùy chỉnh vào trang chỉnh sửa form.
 */
function cfe_add_contact_form_meta_box() {
    add_meta_box(
        'cfe-contact-form-settings',
        __( 'Cài đặt Form và Email', 'cfe-contact-form' ),
        'cfe_contact_form_meta_box_callback',
        'cfe_contact_form',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'cfe_add_contact_form_meta_box' );

/**
 * Enqueue scripts và styles cho trang chỉnh sửa form.
 */
function cfe_admin_forms_assets($hook) {
    global $post;
    if ( $hook === 'post.php' || $hook === 'post-new.php' ) {
        if ( is_object($post) && 'cfe_contact_form' === $post->post_type ) {
            wp_enqueue_style( 'cfe-admin-form-style', CFE_PLUGIN_URL . 'assets/css/admin-form.css', array(), '1.0' );
            wp_enqueue_script( 'cfe-admin-form-script', CFE_PLUGIN_URL . 'assets/js/form-builder.js', array('jquery', 'jquery-ui-sortable'), '1.0', true );
        }
    }
}
add_action( 'admin_enqueue_scripts', 'cfe_admin_forms_assets' );

/**
 * Hiển thị nội dung Meta Box.
 */
function cfe_contact_form_meta_box_callback( $post ) {
    wp_nonce_field( 'cfe_save_meta_box_data', 'cfe_meta_box_nonce' );

    $fields = get_post_meta( $post->ID, 'cfe_form_fields', true );
    $fields = is_array($fields) ? $fields : array();

    $email_settings = get_post_meta( $post->ID, 'cfe_email_settings', true );
    $autoresponder_settings = get_post_meta( $post->ID, 'cfe_autoresponder_settings', true );
    $recaptcha_enabled = get_post_meta( $post->ID, 'cfe_recaptcha_enabled', true );
    ?>
    <div class="cfe-form-settings-wrap">
        <h3>Shortcode</h3>
        <p class="cfe-note">Sử dụng shortcode sau để hiển thị form trên trang:</p>
        <div class="cfe-shortcode-preview">[cfe_contact_form id="<?php echo esc_attr($post->ID); ?>"]</div>

        <h3>Cấu hình Form</h3>
        <p class="cfe-note">Kéo và thả các trường để sắp xếp lại.</p>
        <div id="cfe-form-fields-container" class="cfe-fields-container">
            <?php foreach ($fields as $index => $field): ?>
                <div class="cfe-field-item">
                    <div class="cfe-field-handle">
                        <span class="dashicons dashicons-move"></span>
                    </div>
                    <div class="cfe-field-content">
                        <div class="cfe-form-group">
                            <label>Tên trường</label>
                            <input type="text" name="cfe_form_fields[<?php echo esc_attr($index); ?>][label]" value="<?php echo esc_attr($field['label'] ?? ''); ?>" placeholder="Tên của bạn" required>
                        </div>
                        <div class="cfe-form-group">
                            <label>Slug (tên biến)</label>
                            <input type="text" name="cfe_form_fields[<?php echo esc_attr($index); ?>][name]" value="<?php echo esc_attr($field['name'] ?? ''); ?>" placeholder="ten_cua_ban" required>
                        </div>
                        <div class="cfe-form-group">
                            <label>Loại trường</label>
                            <select name="cfe_form_fields[<?php echo esc_attr($index); ?>][type]">
                                <option value="text" <?php selected($field['type'] ?? '', 'text'); ?>>Text</option>
                                <option value="email" <?php selected($field['type'] ?? '', 'email'); ?>>Email</option>
                                <option value="textarea" <?php selected($field['type'] ?? '', 'textarea'); ?>>Textarea</option>
                            </select>
                        </div>
                        <div class="cfe-form-group">
                            <label>Trường bắt buộc</label>
                            <input type="checkbox" name="cfe_form_fields[<?php echo esc_attr($index); ?>][required]" value="1" <?php checked($field['required'] ?? '', '1'); ?>>
                        </div>
                        <button type="button" class="cfe-remove-field">Xóa</button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <button type="button" id="cfe-add-field" class="button button-secondary">Thêm trường mới</button>

        <hr>

        <h3>Cài đặt reCAPTCHA</h3>
        <div class="cfe-form-group">
            <label>Bật Google reCAPTCHA v2</label>
            <input type="checkbox" name="cfe_recaptcha_enabled" value="1" <?php checked($recaptcha_enabled, '1'); ?>>
            <p class="cfe-note">Bạn phải nhập Site Key và Secret Key trong mục Cài đặt reCAPTCHA của plugin để sử dụng tính năng này.</p>
        </div>

        <hr>

        <h3>Cấu hình Email Thông báo</h3>
        <div class="cfe-form-group">
            <label>Người nhận email</label>
            <input type="email" name="cfe_email_settings[recipient]" value="<?php echo esc_attr($email_settings['recipient'] ?? get_bloginfo('admin_email')); ?>" placeholder="admin@example.com">
        </div>
        <div class="cfe-form-group">
            <label>Tiêu đề email</label>
            <input type="text" name="cfe_email_settings[subject]" value="<?php echo esc_attr($email_settings['subject'] ?? 'Thông tin liên hệ mới từ website'); ?>" placeholder="Thông tin liên hệ mới">
        </div>
        <div class="cfe-form-group">
            <label>Template email</label>
            <textarea name="cfe_email_settings[template]" placeholder="Dữ liệu liên hệ sẽ được gửi tại đây"><?php echo esc_textarea($email_settings['template'] ?? 'Dữ liệu liên hệ sẽ được gửi tại đây'); ?></textarea>
            <p class="cfe-note">Bạn có thể sử dụng các biến như `{sender_name}`, `{sender_email}` và `{field_name}` (ví dụ: `{ten_cua_ban}`) trong template này.</p>
        </div>

        <hr>

        <h3>Cấu hình Email Phản hồi Tự động</h3>
        <div class="cfe-form-group">
            <label>Bật email phản hồi tự động</label>
            <input type="checkbox" name="cfe_autoresponder_settings[enabled]" value="1" <?php checked($autoresponder_settings['enabled'] ?? '', '1'); ?>>
        </div>
        <div class="cfe-form-group">
            <label>Tiêu đề email</label>
            <input type="text" name="cfe_autoresponder_settings[subject]" value="<?php echo esc_attr($autoresponder_settings['subject'] ?? 'Cảm ơn bạn đã liên hệ!'); ?>" placeholder="Cảm ơn bạn đã liên hệ">
        </div>
        <div class="cfe-form-group">
            <label>Nội dung email</label>
            <textarea name="cfe_autoresponder_settings[body]" placeholder="Nội dung email phản hồi tự động"><?php echo esc_textarea($autoresponder_settings['body'] ?? 'Cảm ơn bạn đã gửi liên hệ. Chúng tôi sẽ phản hồi lại bạn sớm nhất có thể!'); ?></textarea>
            <p class="cfe-note">Bạn có thể sử dụng các biến như `{sender_name}`.</p>
        </div>
    </div>
    <?php
}

/**
 * Lưu dữ liệu Meta Box khi form được lưu.
 */
function cfe_save_contact_form_meta_box( $post_id ) {
    if ( ! isset( $_POST['cfe_meta_box_nonce'] ) ) {
        return;
    }

    if ( ! wp_verify_nonce( $_POST['cfe_meta_box_nonce'], 'cfe_save_meta_box_data' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    // Lưu các trường form
    $fields = isset( $_POST['cfe_form_fields'] ) ? $_POST['cfe_form_fields'] : array();
    update_post_meta( $post_id, 'cfe_form_fields', $fields );

    // Lưu cài đặt email
    $email_settings = isset( $_POST['cfe_email_settings'] ) ? $_POST['cfe_email_settings'] : array();
    update_post_meta( $post_id, 'cfe_email_settings', $email_settings );

    // Lưu cài đặt email phản hồi tự động
    $autoresponder_settings = isset( $_POST['cfe_autoresponder_settings'] ) ? $_POST['cfe_autoresponder_settings'] : array();
    update_post_meta( $post_id, 'cfe_autoresponder_settings', $autoresponder_settings );

    // Lưu cài đặt reCAPTCHA
    $recaptcha_enabled = isset( $_POST['cfe_recaptcha_enabled'] ) ? 1 : 0;
    update_post_meta( $post_id, 'cfe_recaptcha_enabled', $recaptcha_enabled );
}
add_action( 'save_post', 'cfe_save_contact_form_meta_box' );