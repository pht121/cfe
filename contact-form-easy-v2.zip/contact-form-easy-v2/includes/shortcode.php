<?php
/**
 * Chức năng tạo shortcode cho form liên hệ.
 */

defined( 'ABSPATH' ) or die( 'Không có quyền truy cập trực tiếp.' );

/**
 * Render form liên hệ bằng shortcode.
 *
 * @param array $atts Thuộc tính shortcode.
 * @return string HTML của form.
 */
function cfe_contact_form_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'id' => '',
    ), $atts, 'cfe_contact_form' );

    $form_post = get_post( (int)$atts['id'] );
    if ( !$form_post || $form_post->post_type !== 'cfe_contact_form' ) {
        return '<p>Lỗi: Form liên hệ không tồn tại hoặc ID không hợp lệ.</p>';
    }

    $form_id = $form_post->ID;
    $fields = get_post_meta( $form_id, 'cfe_form_fields', true );
    $fields = is_array($fields) ? $fields : array();
    $recaptcha_enabled = get_post_meta( $form_id, 'cfe_recaptcha_enabled', true );
    $site_key = get_option('cfe_recaptcha_site_key');

    // Nếu reCAPTCHA được bật và có Site Key, enqueue script của Google
    if ($recaptcha_enabled && !empty($site_key)) {
        wp_enqueue_script('google-recaptcha', 'https://www.google.com/recaptcha/api.js', array(), null, true);
    }
    
    ob_start();
    ?>
    <div class="cfe-contact-form-container">
        <form id="cfe-contact-form-<?php echo esc_attr($form_id); ?>" class="cfe-contact-form" data-form-id="<?php echo esc_attr($form_id); ?>" method="post">
            <?php foreach ($fields as $field): 
                $field_name = isset($field['name']) ? sanitize_title($field['name']) : '';
                $field_label = isset($field['label']) ? esc_html($field['label']) : '';
                $field_type = isset($field['type']) ? esc_attr($field['type']) : 'text';
                $is_required = isset($field['required']) && $field['required'] == '1';
            ?>
                <div class="cfe-form-group">
                    <label for="cfe-<?php echo esc_attr($form_id); ?>-<?php echo esc_attr($field_name); ?>"><?php echo $field_label; ?> <?php if ($is_required) echo '<span class="cfe-required-mark">*</span>'; ?></label>
                    <?php if ($field_type === 'textarea'): ?>
                        <textarea name="<?php echo esc_attr($field_name); ?>" id="cfe-<?php echo esc_attr($form_id); ?>-<?php echo esc_attr($field_name); ?>" rows="5" <?php if ($is_required) echo 'required'; ?>></textarea>
                    <?php else: ?>
                        <input type="<?php echo esc_attr($field_type); ?>" name="<?php echo esc_attr($field_name); ?>" id="cfe-<?php echo esc_attr($form_id); ?>-<?php echo esc_attr($field_name); ?>" <?php if ($is_required) echo 'required'; ?>>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
            
            <?php if ($recaptcha_enabled && !empty($site_key)): ?>
            <div class="cfe-form-group cfe-recaptcha-field">
                <div class="g-recaptcha" data-sitekey="<?php echo esc_attr($site_key); ?>"></div>
            </div>
            <?php endif; ?>

            <div class="cfe-form-group">
                <button type="submit" class="cfe-submit-button">Gửi</button>
            </div>
        </form>
        <div id="cfe-form-message-<?php echo esc_attr($form_id); ?>" class="cfe-form-message" style="display:none;"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'cfe_contact_form', 'cfe_contact_form_shortcode' );