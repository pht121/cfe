<?php
/**
 * Chức năng cấu hình SMTP cho plugin.
 */

defined( 'ABSPATH' ) or die( 'Không có quyền truy cập trực tiếp.' );

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

/**
 * Hiển thị trang cài đặt plugin.
 */
function cfe_settings_page() {
    if ( isset( $_POST['cfe_settings_form'] ) && $_POST['cfe_settings_form'] == '1' ) {
        if ( ! current_user_can( 'manage_options' ) || ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'cfe-settings-nonce' ) ) {
            return;
        }
        $settings = array(
            'smtp_host' => sanitize_text_field( $_POST['smtp_host'] ),
            'smtp_port' => sanitize_text_field( $_POST['smtp_port'] ),
            'smtp_username' => sanitize_text_field( $_POST['smtp_username'] ),
            'smtp_password' => sanitize_text_field( $_POST['smtp_password'] ),
            'smtp_encryption' => sanitize_text_field( $_POST['smtp_encryption'] ),
        );
        update_option( 'cfe_settings', $settings );
    }

    $settings = get_option( 'cfe_settings', array() );
    ?>
    <div class="wrap">
        <h2>Cài đặt Plugin CFE</h2>
        <form method="post" action="">
            <?php wp_nonce_field( 'cfe-settings-nonce' ); ?>
            <input type="hidden" name="cfe_settings_form" value="1" />
            <h3>Cấu hình SMTP</h3>
            <p>Thiết lập thông tin SMTP để email từ trang web của bạn được gửi đi một cách đáng tin cậy.</p>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="smtp_host">SMTP Host</label></th>
                    <td><input type="text" name="smtp_host" id="smtp_host" value="<?php echo esc_attr( $settings['smtp_host'] ?? '' ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_port">SMTP Port</label></th>
                    <td><input type="text" name="smtp_port" id="smtp_port" value="<?php echo esc_attr( $settings['smtp_port'] ?? '' ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_username">Tên người dùng SMTP</label></th>
                    <td><input type="text" name="smtp_username" id="smtp_username" value="<?php echo esc_attr( $settings['smtp_username'] ?? '' ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_password">Mật khẩu SMTP</label></th>
                    <td><input type="password" name="smtp_password" id="smtp_password" value="<?php echo esc_attr( $settings['smtp_password'] ?? '' ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_encryption">Mã hóa</label></th>
                    <td>
                        <select name="smtp_encryption" id="smtp_encryption">
                            <option value="ssl" <?php selected( $settings['smtp_encryption'] ?? '', 'ssl' ); ?>>SSL</option>
                            <option value="tls" <?php selected( $settings['smtp_encryption'] ?? '', 'tls' ); ?>>TLS</option>
                            <option value="none" <?php selected( $settings['smtp_encryption'] ?? '', 'none' ); ?>>Không</option>
                        </select>
                    </td>
                </tr>
            </table>
            <?php submit_button('Lưu Thay Đổi'); ?>
        </form>
    </div>
    <?php
}

/**
 * Cấu hình SMTP bằng PHPMailer.
 */
function cfe_configure_smtp($phpmailer) {
    $settings = get_option('cfe_settings', array());
    if (empty($settings['smtp_host']) || empty($settings['smtp_port'])) {
        return;
    }
    $phpmailer->isSMTP();
    $phpmailer->Host = $settings['smtp_host'];
    $phpmailer->Port = $settings['smtp_port'];
    $phpmailer->SMTPSecure = $settings['smtp_encryption'] === 'none' ? '' : $settings['smtp_encryption'];
    $phpmailer->SMTPAuth = !empty($settings['smtp_username']) && !empty($settings['smtp_password']);
    $phpmailer->Username = $settings['smtp_username'];
    $phpmailer->Password = $settings['smtp_password'];
    $phpmailer->From = $settings['smtp_username'];
    $phpmailer->FromName = get_bloginfo('name');
    $phpmailer->CharSet = 'UTF-8';
}
add_action('phpmailer_init', 'cfe_configure_smtp');